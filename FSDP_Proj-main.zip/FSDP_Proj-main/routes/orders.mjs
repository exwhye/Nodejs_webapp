import { Router } from 'express';
import { ModelProduct } from '../data/createProduct.mjs';
import { ModelCart } from '../data/cart.mjs';
import { ModelUser } from '../data/user.mjs';
import { ModelOrder} from '../data/orders.mjs';
import Sequelize from 'sequelize';
const router = Router();
export default router;

router.get("/", orders)
router.get("/order-data", orderData)
router.get("/ordersInfo", ordersInfo)
router.post("/ordersDel", bulkDelOrders)

async function orders(req,res){
    if (!res.locals.user || res.locals.user.role === "Guest") {
        return res.redirect('/error403')
    }
        console.log(res.locals)
        ModelOrder.findAll().then((products) => {
            return res.render('staff/orders/orders.html')
        }).catch(err => console.log(err))
}

const Op = Sequelize.Op

async function orderData(req, res) {
    /**
         * @type {WhereOptions}
         */
    const condition = (req.query.search) ? {
        [Op.or]: {
            "username": { [Op.substring]: req.query.search }           
        }
    } : undefined;

    const total = await ModelOrder.count({
        where: condition
    });

    const orders = await ModelOrder.findAll({
        where: condition,
        // offset: parseInt(req.query.offset),
        // limit: parseInt(req.query.limit),
        order: (req.query.sort) ? [[req.query.sort, req.query.order.toUpperCase()]] : undefined,
        raw: true
    })
    return res.json({
        "total": total,
        "rows": orders
    });
};

async function ordersInfo(req,res){
    //const cuid = "2d7316ff-6f60-4c03-bebb-7d289b001c69";
    const ouid = req.query.id
    const items = await ModelOrder.findOne({
        where: {
                //uuid_user: cuid,
            order_uuid:ouid
        }
    });
    console.log(items.receiveBy)

    return res.render('staff/orders/ordersInfo.html',{
        orderID:ouid,
        username:items.username,
        address:items.cartItems.address,
        phoneNumber:items.phoneNumber,
        email:items.email,
        dateUpdated:items.dateUpdated.toLocaleString(),
        cart:items.cartItems.Products,
        total:items.total,
        receiveBy:items.receiveBy
    })
}

async function bulkDelOrders(req, res) {
    try {
        await ModelOrder.destroy({
            truncate: true
        })

    } catch (error) {
        console.error(error);
        return res.status(500).end();
    };

    console.log("Orders deleted in bulk")
    return res.redirect('/staff/orders')

}