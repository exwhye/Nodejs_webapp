import {ModelCode} from '../data/code.mjs';
import { ModelUser } from '../data/user.mjs';
import { ModelDiscount } from '../data/discounts.mjs';
import { Router } from 'express';
import Sequelize from 'sequelize';
const router = Router();
export default router;
// retrieve codes page for staff
router.get("/check",checkform)
router.post("/check",checkdata)
router.get("/checked",checked)
router.get("/apply",apply)
router.get("/display",show)
async function checkform(req, res) {
    return res.render('checkform.html', {})
}
async function checkdata(req,res) {
    try {
        const code = await ModelCode.findOne({where: {code : req.body.code }})
        if(code.code == null){
            throw console.error("invalid code");
        }
        console.log(req.body.code)
        res.redirect("/discounts/checked?code="+code.code)
    } catch (error) {
        
    }
}
async function checked(req,res){
    try{
        console.log(req.query.code)
        const check = await ModelCode.findOne({where:{code:req.query.code}})
        if(check.code == null){
            throw console.error("invalid code");
        }
        res.render("check.html",{code:check})
    }catch(error){
        res.redirect("/discounts/check")
    }
}
async function apply(req,res){
    try{
        const code = await ModelCode.findOne({where:{code:req.query.code}})
        if(code.code == null){
            throw "invalid code";
        }
        ModelDiscount.create({
            code:code.uuid,
            account:res.locals.user.uuid
        })
        res.redirect("/discounts/display")
    }catch(error){
        res.redirect("/")
    }
}
async function show(req,res){
    const user = await ModelUser.findOne({where:{uuid:"res.locals.user.uuid"},include:[{model:ModelCode, as:"Codes"}]});
    var codes = user.Codes
    var off = 0
    var price = 100
    codes.forEach(element => {
        if (element.type == "%") {
            off+= price/100*element.amount
            console.log(price/100*element.amount)

        } else {
            off+= element.formatedamount
            console.log(element.formatedamount)
        }
    });
    return res.render("ordereditems.html",{codes:codes,total:price,off:off})
}