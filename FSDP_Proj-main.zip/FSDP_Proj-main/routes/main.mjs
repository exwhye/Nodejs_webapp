import { Router } from 'express';
import twilio from 'twilio';

const router = Router();
export default router;

import nodemailer from 'nodemailer';
import { ModelUser } from '../data/user.mjs';
import Sequelize from 'sequelize';
import multer from 'multer';
var upload = multer({ dest: 'public/userPic' })
import fs from 'fs';
import Hash from 'hash.js';
import JWT from 'jsonwebtoken';


// Imports OP from sequelize

const Op = Sequelize.Op


// If user is not verified, ie. res.locals.user.verified == 0, redirect back to ('/') note to joel


// ---------------- 
//	Serves dynamic files from the dynamic folder
router.get("/dynamic/:path", async function (req, res) {
	return res.sendFile(`${process.cwd()}/dynamic/${req.params.path}`)
});

// ---------------- 
//	TODO: Attach additional routers here
import RouterAuth from './auth.mjs'
router.use("/auth", RouterAuth);

import RouterStaff from './staff.mjs'
import { Console } from 'console';
import { ModelComment } from '../data/comment.mjs';
router.use("/staff", RouterStaff)

import RouterMenu from '../routes/menu.mjs'
router.use("/", RouterMenu)

import RouterCart from '../routes/cart.mjs'
router.use("/cart", RouterCart)
import RouterDiscounts from "../routes/code.mjs"
router.use("/discounts", RouterDiscounts)
// import RouterCart from '../routes/cart.mjs'
// router.use("/", RouterCart)


//	TODO:	Common URL paths here

router.get("/resendotp", resendOTP)
router.get("/review", review);
router.post("/review", review_process);
router.get("/review-data", review_data);
router.get("/profile", profile);
router.get("/verification-failed", verificationFailed)
router.post("/profile", upload.any('avatar'), profile_data);
router.get("/contact", contact);
router.post("/contact", contact_process);



async function resendOTP(req, res) {

	// Sends number verification 

	let accountSID = "AC1c886159e90de587c54a161fcbb7050d";
	let authToken = "7a69192e5a36f1b2eede358fa30f9e23";


	let client = new twilio(accountSID, authToken)

	client.messages
		.create({
			body: 'Dear Customer, Your OTP for Breadington is ' + res.locals.user.phoneNumber_pin + '. Use this Passcode to verify your phone number. Thank you.',
			messagingServiceSid: 'MG0d160ce6e5c9c06e5a148e1d983ab07b',
			to: '+65' + res.locals.user.phoneNumber
		})
		.then(message => console.log(message.sid))
		.done();
}


router.get("/confirmEmail", async function (req, res) {

	// if (res.locals.user.emailVerified != true) {
	// }

	return res.render('confirmEmail.html', {
	});
});



router.get("/confirmEmail/verify/:token", async function (req, res) {
	const token = req.params.token
	try {
		const payload = JWT.verify(token, 'secret');
		ModelUser.update({
			emailVerified: true
		}, {
			where: {
				username: res.locals.user.username
			}
		})
		console.log('User verified! tight as hell gurl YOOO!')
		return res.redirect('/')
	}
	catch (error) {

		console.error(`The token is invalid`);
		console.error(error);
		return res.redirect("/verification-failed")
	}
});


router.post("/confirmEmail", async function (req, res) {
	// Verifies user account via JWT.

	// JWT Token that expires in 30 minutes.
	const secret = 'secret';
	let token = JWT.sign({
		email: req.body.email
	},
		secret, {
		expiresIn: "1hr"
	});
	try {

		// create reusable transporter object using the default SMTP transport
		let transporter = nodemailer.createTransport({
			host: "smtp-mail.outlook.com", // hostname
			secureConnection: false, // TLS requires secureConnection to be false
			port: 587,
			secure: false, // true for 465, false for other ports
			auth: {
				user: "breadington.official@outlook.com", // generated ethereal user
				pass: "Bre@dington558824", // generated ethereal password
			},
			tls: {
				ciphers: 'SSLv3'
			}
		});

		// send mail with defined transport object
		transporter.sendMail({
			from: '"Breadington 👻" breadington.official@outlook.com', // sender address
			to: res.locals.user.email, // list of receivers
			subject: "Hello ✔ Verification", // Subject line
			text: "Please click on this link: http://localhost:3000/confirmEmail/verify/" + token, // plain text body
			html: "<b>Thank you for your registration, " + res.locals.user.username + "! please verify your account here:</b> http://localhost:3000/confirmEmail/verify/" + token + "<br>" + '<img src="cid:unique@nodemailer.com"/>',
			attachments: [{
				filename: 'ThankYou.jpg',
				path: 'public/img/ThankYou.jpg',
				cid: 'unique@nodemailer.com' //same cid value as in the html img src
			}]
		});

		console.log("Message sent");
		return res.status(204)
	}
	catch (error) {

		console.error(`Error sending verification`);
		console.error(error);
		return res.redirect("/verification-failed")
	}

});



async function verificationFailed(req, res) {
	return res.render('verificationFailed.html')
}

// Need to change passing in of "USER OBJECT" instead of just role. This is temporary.
router.get("/", async function (req, res) {


	if (!res.locals.user) {
		return res.redirect('/auth/login')
	}

	// If user is staff, automatically verify email & phone number.

	if (res.locals.user.role == "Staff") {
		ModelUser.update({
			emailVerified: true,
			phoneNumberVerified: true
		}, {
			where: {
				username: res.locals.user.username
			}
		})
	}


	console.log("Home page accessed");
	if (res.locals.user && res.locals.user.role != "Staff") {
		let verified = res.locals.user.emailVerified == 1;
		if (!verified) {
			return res.redirect('/confirmEmail')
		}
	}


	// User signs in, matches hash string with url one.
	if (res.locals.user) {
		if (res.locals.user.verification_hash == req.query.id) {
			ModelUser.update({
				emailVerified: true
			}, {
				where: {
					username: res.locals.user.username
				}
			})
			console.log('User verified! tight as hell gurl YOOO!')
		}
	}
	return res.render('index.html', {
		title: "Hello  Not Today",
	});
});


router.post("/", async function (req, res) {
	console.log(req.body.OTP)
	console.log(res.locals.user.phoneNumber_pin);
	console.log(req.body.OTP == res.locals.user.phoneNumber_pin)


	if (req.body.OTP == res.locals.user.phoneNumber_pin) {
		ModelUser.update({
			phoneNumberVerified: true
		}, {
			where: {
				username: res.locals.user.username
			}
		})
	}
	return res.redirect('../')

});

// go through comment one by one,
// check whether their username equals to current user
// increment!


async function review_data(req, res) {



	const comments = await ModelComment.findAll({ where: { comment: { [Op.ne]: null } } });

	return res.json({

		"rows": comments,
		"total": comments.length
	}
	)
}

async function profile(req, res) {

	if (!res.locals.user) {
		return res.redirect('/auth/login')
	}

	return res.render('customerProfile.html', {
		user: res.locals.user,
		success: req.query.success

	});
}


// res.locals.user

async function profile_data(req, res) {



	if (req.body.password !== undefined) {


		ModelUser.update({
			password: Hash.sha256().update(req.body.password).digest("hex"),
		}, {
			where: { username: res.locals.user.username }
		})
			.catch(err => console.log(err)
			);

		console.log("password updated")
		req.logout();

		return res.redirect('/profile?success=true')


	}

	var paths = req.files.map(file => file.path)

	// if req.body.username // email == user.username // email, let him pass .

	let user = await ModelUser.findOne({ where: { username: res.locals.user.username } })


	if (!!req.files.length) {

		console.log("posting")


		// if (req.body.email == user.email || req.body.password == user.password) {


		if (req.body.email == user.email && req.body.username == user.username) {


			
			if (req.body.number != res.locals.user.phoneNumber) {
				ModelUser.update({

					phoneNumberVerified: "0",
					number: req.body.number
				}, {
					where: { username: res.locals.user.username }
				})
					.catch(err => console.log(err)
					);
			}


			// Delete user previous image
			if (fs.existsSync(user.urlPic)) {
				fs.unlinkSync(user.urlPic)
			}
			try {

				ModelUser.update({
					username: req.body.username,
					email: req.body.email,
					phoneNumber: req.body.number,
					address: req.body.address,
					urlPic: paths[0]
				}, {
					where: { username: res.locals.user.username }
				})

				var userHasComment = ModelComment.findOne({ where: { "username": res.locals.user.username } })

				if (userHasComment) {

					ModelComment.update({
						username: req.body.username,
						urlPic: paths[0]
					}, {
						where: { username: res.locals.user.username }
					})
				}

			}
			catch (error) {
				console.error(error);
			}








			if (req.body.email != res.locals.user.email) {


				if (req.body.email != undefined) {
					ModelUser.update({

						emailVerified: "0",
					}, {
						where: { username: res.locals.user.username }
					})
						.catch(err => console.log(err)
						);


						if (req.body.number != res.locals.user.phoneNumber) {
							ModelUser.update({

								phoneNumberVerified: "0",
							}, {
								where: { username: res.locals.user.username }
							})
								.catch(err => console.log(err)
								);
						}
					req.logout();
				}
			}


			return res.redirect('/profile?success=true')
		}



		// Insert here


		else if (req.body.email == user.email && req.body.username != user.username) {

			console.log("what the fuckkgkfkfkfkfkfkf")

			ModelUser.findOne({ where: { username: req.body.username } })
				.then(user => {
					if (user) {
						console.log("username already registered.")
						return res.render('customerProfile.html', {
							registeredUsername: true,
						});
					}


					else {


						if (req.body.number != res.locals.user.phoneNumber) {
							ModelUser.update({

								phoneNumberVerified: "0",
							}, {
								where: { username: res.locals.user.username }
							})
								.catch(err => console.log(err)
								);
						}

						console.log("what the fuckkgkfkfkfkfkfkf222")



						let user = ModelUser.findOne({ where: { username: res.locals.user.username } })


						if (fs.existsSync(user.urlPic)) {
							fs.unlinkSync(user.urlPic)
						}




						// Retrieve ID from URL



						try {
							ModelUser.update({
								username: req.body.username,
								email: req.body.email,
								phoneNumber: req.body.number,
								address: req.body.address,
								urlPic: paths[0]
							}, {
								where: { username: res.locals.user.username }
							})

							var userHasComment = ModelComment.findOne({ where: { "username": res.locals.user.username } })

							if (userHasComment) {

								ModelComment.update({
									username: req.body.username,
									urlPic: paths[0]
								}, {
									where: { username: res.locals.user.username }
								})
							}

						}

						catch {
							console.error(error);
						}




							

						req.logout();

						return res.redirect('/profile?success=true')












					}
				})


		}


		else if (req.body.email != user.email && req.body.username == user.username) {



			ModelUser.findOne({ where: { email: req.body.email } })
				.then(user => {
					if (user) {
						console.log("email already registered.")
						return res.render('customerProfile.html', {
							registeredEmail: true,
						});
					}
					else {




						let user = ModelUser.findOne({ where: { username: res.locals.user.username } })


						if (fs.existsSync(user.urlPic)) {
							fs.unlinkSync(user.urlPic)
						}



											let userx = ModelUser.findOne({ where: { username: res.locals.user.username } })

											// Retrieve ID from URL



											try {
												ModelUser.update({
													username: req.body.username,
													email: req.body.email,
													phoneNumber: req.body.number,
													address: req.body.address,
													urlPic: paths[0]
												}, {
													where: { username: res.locals.user.username }
												})

												var userHasComment = ModelComment.findOne({ where: { "username": res.locals.user.username } })

												if (userHasComment) {

													ModelComment.update({
														username: req.body.username,
														urlPic: paths[0]
													}, {
														where: { username: res.locals.user.username }
													})
												}

											}

											catch {
												console.error(error);
											}



											if (req.body.number != res.locals.user.phoneNumber) {
												ModelUser.update({

													phoneNumberVerified: "0",
												}, {
													where: { username: res.locals.user.username }
												})
													.catch(err => console.log(err)
													);
											}


											ModelUser.update({

												emailVerified: "0",
											}, {
												where: { username: res.locals.user.username }
											})
												.catch(err => console.log(err)
												);

												if (req.body.number != res.locals.user.phoneNumber) {
													ModelUser.update({
						
														phoneNumberVerified: "0",
													}, {
														where: { username: res.locals.user.username }
													})
														.catch(err => console.log(err)
														);
												}

											req.logout();

											return res.redirect('/profile?success=true')


					}
				}
				)

		}


		else {

			console.log("testing")


				ModelUser.findOne({ where: { email: req.body.email } })
				.then(user => {
					if (user) {
						console.log("email already registered.")
						return res.render('customerProfile.html', {
							registeredEmail: true,
						});
					}

					ModelUser.findOne({ where: { username: req.body.username } })
						.then(user => {
							if (user) {
								console.log("username already registered.")
								return res.render('customerProfile.html', {
									registeredUsername: true,
								});
							}


							else {

								// Retrieve ID from URL



								ModelUser.update({

									emailVerified: "0",
								}, {
									where: { username: res.locals.user.username }
								})
									.catch(err => console.log(err)
									);


									if (req.body.number != res.locals.user.phoneNumber) {
										ModelUser.update({
						
											phoneNumberVerified: "0",
											number: req.body.number
										}, {
											where: { username: res.locals.user.username }
										})
											.catch(err => console.log(err)
											);
									}



								try {
									ModelUser.update({
										username: req.body.username,
										email: req.body.email,
										phoneNumber: req.body.number,
										address: req.body.address,
										urlPic: paths[0]
									}, {
										where: { username: res.locals.user.username }
									})

									var userHasComment = ModelComment.findOne({ where: { "username": res.locals.user.username } })

									if (userHasComment) {

										ModelComment.update({
											username: req.body.username,
											urlPic: paths[0]
										}, {
											where: { username: res.locals.user.username }
										})
									}

								}

								catch {
									console.error(error);
								}



								req.logout();

								return res.redirect('/profile?success=true')





							}
						}
						);
				});





		}

	}
	else {






		if (req.body.email == user.email && req.body.username == user.username) {

			if (req.body.number != res.locals.user.phoneNumber) {
				ModelUser.update({

					phoneNumberVerified: "0",
					number: req.body.number
				}, {
					where: { username: res.locals.user.username }
				})
					.catch(err => console.log(err)
					);
			}

			try {
				ModelUser.update({
					username: req.body.username,
					email: req.body.email,
					phoneNumber: req.body.number,
					address: req.body.address,
				}, {
					where: { username: res.locals.user.username }
				})

				var userHasComment = ModelComment.findOne({ where: { "username": res.locals.user.username } })

				if (userHasComment) {

					ModelComment.update({
						username: req.body.username,
						// urlPic: paths[0]
					}, {
						where: { username: res.locals.user.username }
					})
				}

			}

			catch {
				console.error(error);
			}



			return res.redirect('/profile?success=true')



		}

		else {

			// If it's a new email, and used one, prevent submission.



			if (req.body.email == user.email && req.body.username != user.username) {

				ModelUser.findOne({ where: { username: req.body.username } })
					.then(user => {
						if (user) {
							console.log("username already registered.")
							return res.render('customerProfile.html', {
								registeredUsername: true,
							});
						}


						else {

							// Retrieve ID from URL

							if (req.body.number != res.locals.user.phoneNumber) {
								ModelUser.update({
				
									phoneNumberVerified: "0",
									number: req.body.number
								}, {
									where: { username: res.locals.user.username }
								})
									.catch(err => console.log(err)
									);
							}

							try {
								ModelUser.update({
									username: req.body.username,
									email: req.body.email,
									phoneNumber: req.body.number,
									address: req.body.address,
								}, {
									where: { username: res.locals.user.username }
								})

								var userHasComment = ModelComment.findOne({ where: { "username": res.locals.user.username } })

								if (userHasComment) {

									ModelComment.update({
										username: req.body.username,
										// urlPic: paths[0]
									}, {
										where: { username: res.locals.user.username }
									})
								}

							}

							catch {
								console.error(error);
							}



							return res.redirect('/profile?success=true')


						}
					}
					);

			}


			else if (req.body.email != user.email && req.body.username == user.username) {

				ModelUser.findOne({ where: { email: req.body.email } })
					.then(user => {
						if (user) {
							console.log("email already registered.")
							return res.render('customerProfile.html', {
								registeredEmail: true,
							});
						}
						else {

							ModelUser.update({

								emailVerified: "0",
							}, {
								where: { username: res.locals.user.username }
							})
								.catch(err => console.log(err)
								);


							// Retrieve ID from URL

							if (req.body.number != res.locals.user.phoneNumber) {
								ModelUser.update({
				
									phoneNumberVerified: "0",
									number: req.body.number
								}, {
									where: { username: res.locals.user.username }
								})
									.catch(err => console.log(err)
									);
							}


							try {
								ModelUser.update({
									username: req.body.username,
									email: req.body.email,
									phoneNumber: req.body.number,
									address: req.body.address,
								}, {
									where: { username: res.locals.user.username }
								})

								var userHasComment = ModelComment.findOne({ where: { "username": res.locals.user.username } })

								if (userHasComment) {

									ModelComment.update({
										username: req.body.username,
										// urlPic: paths[0]
									}, {
										where: { username: res.locals.user.username }
									})
								}

							}

							catch {
								console.error(error);
							}








							req.logout();

							return res.redirect('/profile?success=true')


						}
					}
					);

			}


			else {





				ModelUser.findOne({ where: { email: req.body.email } })
					.then(user => {
						if (user) {
							console.log("email already registered.")
							return res.render('customerProfile.html', {
								registeredEmail: true,
							});
						}

						ModelUser.findOne({ where: { username: req.body.username } })
							.then(user => {
								if (user) {
									console.log("username already registered.")
									return res.render('customerProfile.html', {
										registeredUsername: true,
									});
								}


								else {

									// Retrieve ID from URL



									ModelUser.update({

										emailVerified: "0",
									}, {
										where: { username: res.locals.user.username }
									})
										.catch(err => console.log(err)
										);


										if (req.body.number != res.locals.user.phoneNumber) {
											ModelUser.update({
							
												phoneNumberVerified: "0",
												number: req.body.number
											}, {
												where: { username: res.locals.user.username }
											})
												.catch(err => console.log(err)
												);
										}



									try {
										ModelUser.update({
											username: req.body.username,
											email: req.body.email,
											phoneNumber: req.body.number,
											address: req.body.address,
										}, {
											where: { username: res.locals.user.username }
										})

										var userHasComment = ModelComment.findOne({ where: { "username": res.locals.user.username } })

										if (userHasComment) {

											ModelComment.update({
												username: req.body.username,
												// urlPic: paths[0]
											}, {
												where: { username: res.locals.user.username }
											})
										}

									}

									catch {
										console.error(error);
									}



									req.logout();

									return res.redirect('/profile?success=true')





								}
							}
							);
					});








			}


		}

	}


}

async function review(req, res) {


	return res.render('customerReview.html', {
		user: res.locals.user,
		alert: req.query.alert
	});
}




async function review_process(req, res) {


	const comments = await ModelComment.findAll({
		where: { username: res.locals.user.username },
		order: [['dateCreated', 'DESC']]
	});



	if (!!comments.length) {


		if ((new Date().getTime() - comments[0].dateCreated.getTime()) / 1000 <= 30) {

			return res.redirect("/review?alert=true")


		}

		else {


			// Find latest comment y user
			// Compare date to current date
			// if less than, bring up modal and

			var urlPic = res.locals.user.urlPic
			var username = res.locals.user.username
			var verified = res.locals.user.emailVerified
			var comment = req.body.comment
			var role = res.locals.user.role
			ModelComment.create({ username: res.locals.user.username, urlPic: res.locals.user.urlPic, emailVerified: verified, comment: comment, role: role, dateCreated: new Date() })

			// ModelUser.update({
			// 	comment: req.body.comment
			// }, {
			// 	where: {
			// 		username: res.locals.user.username
			// 	}
			// })
			// 	.catch(err => console.log(err));
			// return res.redirect('../review')
			return res.redirect("/review")
		}
	}
	else {
		var urlPic = res.locals.user.urlPic
		var username = res.locals.user.username
		var verified = res.locals.user.emailVerified
		var comment = req.body.comment
		var role = res.locals.user.role
		ModelComment.create({ username: res.locals.user.username, urlPic: res.locals.user.urlPic, emailVerified: verified, comment: comment, role: role, dateCreated: new Date() })
		return res.redirect("/review")

	}

}

async function contact(req, res) {
	return res.render('contact.html', {
		msgSent: req.query.sent
	});
}

// Why does contact prompt user for email & number again?
// Some user have not verified their email / number
// they might wonder why it doesnt send them the verification link
// Hence support is used to ensure that they've entered correct ones.

async function contact_process(req, res) {

	// Sends an email to official breadington team from breadington's support email

	try {
		// create reusable transporter object using the default SMTP transport
		let transporter = nodemailer.createTransport({
			host: "smtp.gmail.com", // hostname
			secureConnection: false, // TLS requires secureConnection to be false
			port: 587,
			secure: false, // true for 465, false for other ports
			auth: {
				user: "contact.breadington.official@gmail.com", // generated ethereal user
				pass: "Bre@dington558824", // generated ethereal password
			},
			tls: {
				ciphers: 'SSLv3'
			}
		});
		// send mail with defined transport object
		transporter.sendMail({
			from: '"Breadington Customer Support 👻 "contact.breadington.official@gmail.com', // sender address
			to: "breadington.official@outlook.com", // list of receivers
			subject: "Customer Support / Enquiry", // Subject line
			text: "Customer Support", //Plain text body.
			html: `<b>Customer Name</b>:${req.body.name}<br><b>Customer Email</b>:${req.body.email}<br><b>Customer Number:</b> ${req.body.number}<br><b>Customer Message:</b> ${req.body.message}`,
		});

		console.log("Message sent");
		return res.redirect("/contact?sent=true")
	}
	catch (error) {
		console.error(error);
	}
	return res.render('contact.html', {
	});
}



router.get("/about", async function (req, res) {
	console.log("About page accessed");
	return res.render('about.html', {
		author: "The awesome programmer",
		values: [1, 2, 3, 4, 5, 6]
	});
});

router.get("/home", async function (req, res) {
	console.log("Home page accessed");
	return res.render('home.html', {
	});
});

router.get("/error404", async function (req, res) {
	return res.render('error404.html', {
	});
});

router.get("/error403", async function (req, res) {
	return res.render('error403.html', {
	});
});
