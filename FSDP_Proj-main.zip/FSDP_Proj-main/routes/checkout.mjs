import { Router } from 'express';
import { ModelProduct } from '../data/createProduct.mjs';
import { ModelCart } from '../data/cart.mjs';
import { ModelUser } from '../data/user.mjs';
import sequelize from 'sequelize';
import { ModelOrder } from '../data/orders.mjs';
const router = Router();
export default router;

router.get("/", Checkout)
router.get("/success",checkoutSuccess)
router.post("/addOrders",addOrders)


async function Checkout(req,res){
    try {
        const user = req.user.uuid
        const items = await ModelUser.findOne({
            where: {
                uuid: user,
            },
            include: [{ model: ModelProduct, as: "Products" }]
        });
        console.log(items)
        
        const getTotal = await ModelCart.findAll({
            attributes: ['uuid_user', [sequelize.fn('sum', sequelize.col('subTotal')), 'total']],
            raw: true,
          });
        const total = getTotal[0].total

        const getCount = await ModelCart.findAll({
        attributes: ['uuid_user', [sequelize.fn('count', sequelize.col('uuid_user')), 'count']],
        raw: true,
        });
        const getCartandProduct = items.Products
        const ordercart = JSON.stringify(getCartandProduct)
        return res.render('customer/checkout.html', {
            username:items.username,
            email:items.email,
            phoneNumber:items.phoneNumber,
            address:items.address,
            cart: getCartandProduct,
            total:total,
            count: getCount,
            ordercart:ordercart,
        })
    }
    catch (err) {
        console.log(err);
        res.status(500).send("Something went wrong");
    }
}

async function checkoutSuccess(req,res){
    const cuid = req.user.uuid
    const items = await ModelOrder.findOne({
        where: {
             uuid_user: cuid,
        }
    });

    return res.render('customer/paymentSuccess.html',{
        orderID:items.order_uuid,
        username:items.username,
        address:items.cartItems.address,
        phoneNumber:items.phoneNumber,
        dateUpdated:items.dateUpdated.toLocaleString(),
        cart:items.cartItems.Products,
        total:items.total,
        email:items.cartItems.email,
        receiveBy:items.receiveBy
    })
}

async function addOrders(req,res){
    const cuid = req.user.uuid
    const username = req.body.username
    const email = req.body.email
    const hpnum = req.body.phoneNumber
    const address =  req.body.address
    const receiveBy = req.body.receiveBy
    const total = req.body.total
    try {
        const items = await ModelUser.findOne({
            where: {
                uuid: cuid,
            },
            include: [{ model: ModelProduct, as: "Products" }]
        });
        const getCartandProduct = items
        const ordercart = JSON.stringify(getCartandProduct)
        const cartItems = JSON.parse(ordercart)
        const order = await ModelOrder.create({
            uuid_user:cuid,
            username:username,
            email:email,
            phoneNumber:hpnum,
            receiveBy:receiveBy,
            address:address,
            total:total,
            cartItems:cartItems
        });
        console.log("order is successfully created")
        try {
            await ModelCart.destroy({
                truncate: true
            })
    
        } catch (error) {
            console.error(error);
            return res.status(500).end();
        };
    
        console.log("cart deleted after a successful order")

        return res.sendStatus(200)
    }
    catch (error) {
        console.error(error);
        return res.sendStatus(400).end();
    }
    
}

