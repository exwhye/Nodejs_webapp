import { Router } from 'express';
//import WalkInUser from '../data/createWalk.mjs';
//import Code from '../data/code.mjs';
import Hash from 'hash.js';



const router = Router();
export default router;

//rout to product.mjs -xy
import RouterProduct from '../routes/product.mjs'
router.use("/", RouterProduct)
//route to orders -xy
import RouterOrders from '../routes/orders.mjs'
router.use("/orders", RouterOrders)

import Routercode from '../routes/staffcodes.mjs'
router.use("/codes", Routercode)

import RouterReward from '../routes/staffrewards.mjs'
router.use("/rewards", RouterReward)


// Imports model user for database
import { ModelUser } from '../data/user.mjs';
import Sequelize from 'sequelize';
import multer from 'multer';
var upload = multer({ dest: 'public/userPic' })
import fs from 'fs';
import JWT from 'jsonwebtoken';
import nodemailer from 'nodemailer';


// rout to walkInUser.mjs -yh
import RouterWalkInUser from '../routes/WalkInUser.mjs'
import { ModelComment } from '../data/comment.mjs';
import { Console } from 'console';
router.use("/walkInUser", RouterWalkInUser)

router.get("/accounts/list", viewUser_page);
router.get("/accounts/list/data", viewUser_data);
router.get("/accounts/createUsers", createUser_page);
router.post("/accounts/createUsers", upload.single('avatar'), createUser_process);
router.get("/accounts/deleteUser", deleteUser_process);
router.get("/accounts/updateUsers", updateUser_page);
router.get("/accounts/reset-password/:uuid", resetUserPw);
router.post("/accounts/updateUsers", upload.any('avatar'), updateUser_process);




// Creating users as an admin.

async function createUser_page(req, res) {


    // Enable this to prevent guests from accessing the page.
    if (!res.locals.user || res.locals.user.role == "Guest") {
        return res.redirect('/error403')
    }


    return res.render('staff/accounts/createUsers.html', {
    });
}

async function createUser_process(req, res) {
    console.log(req.file)
    let { username, email, password, password2, phoneNumber, address, role } = req.body;
    console.log(req.body);
    if (req.body.password.length < 4) {
        return res.send('Password must be at least 4 characters')
    }
    else if (req.body.password != req.body.password2) {
        return res.send('Passwords do not match')
    }
    else {
        ModelUser.findOne({ where: { email: req.body.email } })
            .then(user => {
                if (user) {
                    console.log("email already registered.")
                    return res.render('staff/accounts/createUsers.html', {
                        registeredEmail: true,
                    });
                }

                ModelUser.findOne({ where: { username: req.body.username } })
                    .then(user => {
                        if (user) {
                            console.log("username already registered.")

                            return res.render('staff/accounts/createUsers.html', {
                                registeredUsername: true,
                            });
                        }

                        else {
                            ModelUser.create({ username: req.body.username, role: req.body.role, accountStatus: req.body.status, email: req.body.email, password: Hash.sha256().update(req.body.password).digest("hex"), verification_hash: Hash.sha256().update(req.body.email).digest("hex"), phoneNumber: req.body.number, address: req.body.address, phoneNumber_pin: Math.random().toString().substr(2, 4), urlPic: req.file.path })
                                .then(user => {
                                    // alertMessage(res, 'success', user.name + ' added. Please login', 'fas fa-sign-in-alt', true);
                                    return res.redirect('/staff/accounts/list')
                                })
                                .catch(err => console.log(err));
                        }
                    });

            });
    }
}



/**
 * 
 * @param req {import('express').Request}
 * @param res {import('express').Response}
 * @returns 
 */

async function deleteUser_process(req, res) {

    if (!res.locals.user || res.locals.user.role == "Guest") {
        return res.redirect('/error403')
    }


    try {
        ModelComment.findOne({ where: { "username": req.query.id } })
            .then(user => {
                if (user) {

                    if (fs.existsSync(user.urlPic)) {
                        fs.unlinkSync(user.urlPic)
                    }

                    ModelComment.destroy({
                        where: { "username": req.query.id }
                    })
                }
            });

    }
    catch (error) {
        console.error(error);
    }

    finally {

        ModelUser.destroy({
            where: { "username": req.query.id }
        }
        )

    }
    console.log("User deleted")
    return res.redirect('/staff/accounts/list')
}

/**
 * 
 * @param req {import('express').Request}
 * @param res {import('express').Response}
 * @returns 
 */
async function updateUser_page(req, res) {

    let user = await ModelUser.findOne({ where: { username: req.query.id } })


    // Enable this to prevent guests from accessing the page.
    if (!res.locals.user || res.locals.user.role == "Guest") {
        return res.redirect('/error403')
    }



    return res.render('staff/accounts/updateUsers.html', {
        user: user,
        current_user: res.locals.user
    });
}


async function updateUser_process(req, res) {

    var paths = req.files.map(file => file.path)

    // if req.body.username // email == user.username // email, let him pass .

    // Check if user has comment, change username as well.



    let user = await ModelUser.findOne({ where: { username: req.query.id } })
    console.log(user.uuid)


    // Got file yeah
    if (!!req.files.length) {









        console.log("posting")


        // if (req.body.email == user.email || req.body.password == user.password) {


        if (req.body.email == user.email && req.body.username == user.username) {



            if (req.body.number != res.locals.user.phoneNumber) {
                ModelUser.update({

                    phoneNumberVerified: "0",
                    number: req.body.number
                }, {
                    where: { username: req.query.id }
                })
                    .catch(err => console.log(err)
                    );
            }


            // Delete user previous image
            if (fs.existsSync(user.urlPic)) {
                fs.unlinkSync(user.urlPic)
            }
            try {

                ModelUser.update({
                    username: req.body.username,
                    email: req.body.email,
                    phoneNumber: req.body.number,
                    address: req.body.address,
                    role: req.body.role,
                    accountStatus: req.body.status,
                    urlPic: paths[0]
                }, {
                    where: { username: req.query.id }
                })

                var userHasComment = ModelComment.findOne({ where: { "username": req.query.id } })

                if (userHasComment) {

                    ModelComment.update({
                        username: req.body.username,
                        urlPic: paths[0]
                    }, {
                        where: { username: req.query.id }
                    })
                }

            }
            catch (error) {
                console.error(error);
            }








            if (req.body.email != res.locals.user.email) {


                if (req.body.email != undefined) {
                    ModelUser.update({

                        emailVerified: "0",
                    }, {
                        where: { username: req.query.id }
                    })
                        .catch(err => console.log(err)
                        );


                    if (req.body.number != res.locals.user.phoneNumber) {
                        ModelUser.update({

                            phoneNumberVerified: "0",
                        }, {
                            where: { username: req.query.id }
                        })
                            .catch(err => console.log(err)
                            );
                    }
                }
            }


            if (user.username != res.locals.user.username) { return res.redirect('/staff/accounts/list') }
            else {
                req.logout();
                return res.redirect('/auth/login')
            }
        }



        // Insert here


        else if (req.body.email == user.email && req.body.username != user.username) {


            console.log(req.body.username)
            console.log(user.username)


            // username: req.query.id
            // dolphin FUCK

            ModelUser.findOne({ where: { username: req.body.username } })
                .then(user => {
                    if (user) {
                        console.log("username already registered.")





                        ModelUser.findOne({ where: { username: req.query.id } })
                            .then(user => {
                                if (user) {

                                    return res.render('staff/accounts/updateUsers.html', {
                                        registeredUsername: true,
                                        user: user
                                    });
                                }
                            })


                        // return res.redirect('/staff/accounts/updateUsers?id=' + user.username)


                    }




                    else {


                        if (req.body.number != res.locals.user.phoneNumber) {
                            ModelUser.update({

                                phoneNumberVerified: "0",
                            }, {
                                where: { username: req.query.id }
                            })
                                .catch(err => console.log(err)
                                );
                        }

                        console.log("what the fuckkgkfkfkfkfkfkf222")



                        let user = ModelUser.findOne({ where: { username: req.query.id } })


                        if (fs.existsSync(user.urlPic)) {
                            fs.unlinkSync(user.urlPic)
                        }




                        // Retrieve ID from URL



                        try {
                            ModelUser.update({
                                username: req.body.username,
                                email: req.body.email,
                                phoneNumber: req.body.number,
                                address: req.body.address,
                                role: req.body.role,
                                accountStatus: req.body.status,
                                urlPic: paths[0]
                            }, {
                                where: { username: req.query.id }
                            })

                            var userHasComment = ModelComment.findOne({ where: { "username": req.query.id } })

                            if (userHasComment) {

                                ModelComment.update({
                                    username: req.body.username,
                                    urlPic: paths[0]
                                }, {
                                    where: { username: req.query.id }
                                })
                            }

                        }

                        catch {
                            console.error(error);
                        }





                        if (user.username != res.locals.user.username) { return res.redirect('/staff/accounts/list') }
                        else {
                            req.logout();
                            return res.redirect('/auth/login')
                        }













                    }
                })


        }


        else if (req.body.email != user.email && req.body.username == user.username) {




            ModelUser.findOne({ where: { email: req.body.email } })
                .then(user => {
                    if (user) {
                        console.log("email already registered.")



                        ModelUser.findOne({ where: { username: req.query.id } })
                            .then(user => {
                                if (user) {

                                    return res.render('staff/accounts/updateUsers.html', {
                                        registeredEmail: true,
                                        user: user
                                    });
                                }
                            })


                        // return res.redirect('/staff/accounts/updateUsers?id=' + user.username)


                    }
                    else {





                        let user = ModelUser.findOne({ where: { username: req.query.id } })


                        if (fs.existsSync(user.urlPic)) {
                            fs.unlinkSync(user.urlPic)
                        }



                        let userx = ModelUser.findOne({ where: { username: req.query.id } })

                        // Retrieve ID from URL



                        try {
                            ModelUser.update({
                                username: req.body.username,
                                email: req.body.email,
                                phoneNumber: req.body.number,
                                address: req.body.address,
                                role: req.body.role,
                                accountStatus: req.body.status,
                                urlPic: paths[0]
                            }, {
                                where: { username: req.query.id }
                            })

                            var userHasComment = ModelComment.findOne({ where: { "username": req.query.id } })

                            if (userHasComment) {

                                ModelComment.update({
                                    username: req.body.username,
                                    urlPic: paths[0]
                                }, {
                                    where: { username: req.query.id }
                                })
                            }

                        }

                        catch {
                            console.error(error);
                        }



                        if (req.body.number != res.locals.user.phoneNumber) {
                            ModelUser.update({

                                phoneNumberVerified: "0",
                            }, {
                                where: { username: req.query.id }
                            })
                                .catch(err => console.log(err)
                                );
                        }


                        ModelUser.update({

                            emailVerified: "0",
                        }, {
                            where: { username: req.query.id }
                        })
                            .catch(err => console.log(err)
                            );

                        if (req.body.number != res.locals.user.phoneNumber) {
                            ModelUser.update({

                                phoneNumberVerified: "0",
                            }, {
                                where: { username: req.query.id }
                            })
                                .catch(err => console.log(err)
                                );
                        }

                        if (user.username != res.locals.user.username) { return res.redirect('/staff/accounts/list') }
                        else {
                            req.logout();
                            return res.redirect('/auth/login')
                        }



                    }
                }
                )

        }


        else {

            console.log("EGGEGGDOLPHIN")







            let user = ModelUser.findOne({ where: { username: req.query.id } })


            if (fs.existsSync(user.urlPic)) {
                fs.unlinkSync(user.urlPic)
            }







            ModelUser.findOne({ where: { email: req.body.email } })
                .then(user => {
                    if (user) {
                        if (req.body.email != res.locals.user.email && req.body.username == res.locals.user.username) {
                            // benedick


                            ModelUser.findOne({ where: { username: req.query.id } })
                                .then(user => {
                                    if (user) {


                                        ModelUser.findOne({ where: { username: req.query.id } })
                                        .then(user => {
                                            if (user) {
    
                                                return res.render('staff/accounts/updateUsers.html', {
                                                    registeredEmail: true,
                                                    user: user
                                                });
                                            }
                                        })





                                    }
                                })


                        }
                    }

                    ModelUser.findOne({ where: { username: req.body.username } })
                        .then(user => {
                            if (user) {




                                ModelUser.findOne({ where: { username: req.query.id } })
                                    .then(user => {
                                        if (user) {

                                            return res.render('staff/accounts/updateUsers.html', {
                                                registeredUsername: true,
                                                user: user
                                            });
                                        }
                                    })




                            }



                            else {



                                let userx = ModelUser.findOne({ where: { username: req.query.id } })

                                // Retrieve ID from URL

                                ModelUser.update({

                                    emailVerified: "0",
                                }, {
                                    where: { username: req.query.id }
                                })
                                    .catch(err => console.log(err)
                                    );


                                if (req.body.number != res.locals.user.phoneNumber) {
                                    ModelUser.update({

                                        phoneNumberVerified: "0",
                                        number: req.body.number

                                    }, {
                                        where: { username: req.query.id }
                                    })
                                        .catch(err => console.log(err)
                                        );
                                }




                                try {
                                    ModelUser.update({
                                        username: req.body.username,
                                        email: req.body.email,
                                        phoneNumber: req.body.number,
                                        address: req.body.address,
                                        role: req.body.role,
                                        accountStatus: req.body.status,
                                        urlPic: paths[0]
                                    }, {
                                        where: { username: req.query.id }
                                    })

                                    var userHasComment = ModelComment.findOne({ where: { "username": req.query.id } })

                                    if (userHasComment) {

                                        ModelComment.update({
                                            username: req.body.username,
                                            urlPic: paths[0]
                                        }, {
                                            where: { username: req.query.id }
                                        })
                                    }

                                }

                                catch {
                                    console.error(error);
                                }





                                ModelUser.findOne({ where: { username: req.query.id } })
                                .then(user => {
                                    if (user) {

                                        if (user.username != res.locals.user.username) { return res.redirect('/staff/accounts/list') }
                                        else {
                                            req.logout();
                                            return res.redirect('/auth/login')
                                        }

                                    }
                                })















                                // let user = ModelUser.findOne({ where: { username: req.query.id } })

                                // // Retrieve ID from URL

                                // if (fs.existsSync(user.urlPic)) {
                                // 	fs.unlinkSync(user.urlPic)
                                // }
                                // try {
                                // 	ModelUser.update({
                                // 		username: req.body.username,
                                // 		email: req.body.email,
                                // 		phoneNumber: req.body.number,
                                // 		address: req.body.address,
                                // 		urlPic: paths[0]
                                // 	}, {
                                // 		// shabboozey
                                // 		where: { username: req.query.id }
                                // 	})
                                // 	var userHasComment = ModelComment.findOne({ where: { "username": req.query.id } })

                                // 	if (userHasComment) {

                                // 		ModelComment.update({
                                // 			username: req.body.username,
                                // 			urlPic: paths[0]
                                // 		}, {
                                // 			where: { username: req.query.id }
                                // 		})
                                // 	}

                                // }
                                // catch {
                                // 	console.error(error);
                                // }


                                // if (req.body.email != res.locals.user.email) {


                                // 	if (req.body.email != undefined) {
                                // 		ModelUser.update({

                                // 			emailVerified: "0",
                                // 		}, {
                                // 			where: { username: req.query.id }
                                // 		})
                                // 			.catch(err => console.log(err)
                                // 			);
                                // 		req.logout();
                                // 	}
                                // }


                                // return res.redirect('/profile?success=true')







                            }
                        }
                        );
                });



        }

    }










    else {








        console.log("posting")


        // if (req.body.email == user.email || req.body.password == user.password) {


        if (req.body.email == user.email && req.body.username == user.username) {



            if (req.body.number != res.locals.user.phoneNumber) {
                ModelUser.update({

                    phoneNumberVerified: "0",
                    number: req.body.number
                }, {
                    where: { username: req.query.id }
                })
                    .catch(err => console.log(err)
                    );
            }


            // Delete user previous image

            try {

                ModelUser.update({
                    username: req.body.username,
                    email: req.body.email,
                    phoneNumber: req.body.number,
                    address: req.body.address,
                    role: req.body.role,
                    accountStatus: req.body.status,
                }, {
                    where: { username: req.query.id }
                })

                var userHasComment = ModelComment.findOne({ where: { "username": req.query.id } })

                if (userHasComment) {

                    ModelComment.update({
                        username: req.body.username,
                    }, {
                        where: { username: req.query.id }
                    })
                }

            }
            catch (error) {
                console.error(error);
            }








            if (req.body.email != res.locals.user.email) {


                if (req.body.email != undefined) {
                    ModelUser.update({

                        emailVerified: "0",
                    }, {
                        where: { username: req.query.id }
                    })
                        .catch(err => console.log(err)
                        );


                    if (req.body.number != res.locals.user.phoneNumber) {
                        ModelUser.update({

                            phoneNumberVerified: "0",
                        }, {
                            where: { username: req.query.id }
                        })
                            .catch(err => console.log(err)
                            );
                    }
                }
            }


            if (user.username != res.locals.user.username) { return res.redirect('/staff/accounts/list') }
            else {
                req.logout();
                return res.redirect('/auth/login')
            }
        }



        // Insert here


        else if (req.body.email == user.email && req.body.username != user.username) {

            // michaelajackson

            console.log("what the fuckkgkfkfkfkfkfkffuckfuckfuck")

            console.log("here", req.body.username)

            console.log(user.username)

            let idk = user.username



            ModelUser.findOne({ where: { username: req.body.username } })
                .then(user => {
                    if (user) {
                        console.log("username already registered.")

                        // michaeljackson


                        ModelUser.findOne({ where: { username: req.query.id } })
                            .then(user => {
                                if (user) {

                                    return res.render('staff/accounts/updateUsers.html', {
                                        registeredUsername: true,
                                        user: user
                                    });
                                }
                            })


                        // return res.redirect('/staff/accounts/updateUsers?id=' + user.username)


                    }






                    else {


                        if (req.body.number != res.locals.user.phoneNumber) {
                            ModelUser.update({

                                phoneNumberVerified: "0",
                            }, {
                                where: { username: req.query.id }
                            })
                                .catch(err => console.log(err)
                                );
                        }

                        console.log("what the fuckkgkfkfkfkfkfkf222")



                        let user = ModelUser.findOne({ where: { username: req.query.id } })






                        // Retrieve ID from URL



                        try {
                            ModelUser.update({
                                username: req.body.username,
                                email: req.body.email,
                                phoneNumber: req.body.number,
                                address: req.body.address,
                                role: req.body.role,
                                accountStatus: req.body.status,
                            }, {
                                where: { username: req.query.id }
                            })

                            var userHasComment = ModelComment.findOne({ where: { "username": req.query.id } })

                            if (userHasComment) {

                                ModelComment.update({
                                    username: req.body.username,
                                }, {
                                    where: { username: req.query.id }
                                })
                            }

                        }

                        catch {
                            console.error(error);
                        }



                        if (user.username != res.locals.user.username) { return res.redirect('/staff/accounts/list') }
                        else {
                            req.logout();
                            return res.redirect('/auth/login')
                        }













                    }

                })


        }


        else if (req.body.email != user.email && req.body.username == user.username) {



            ModelUser.findOne({ where: { email: req.body.email } })
                .then(user => {
                    if (user) {
                        console.log("email already registered.")



                        ModelUser.findOne({ where: { username: req.query.id } })
                            .then(user => {
                                if (user) {

                                    return res.render('staff/accounts/updateUsers.html', {
                                        registeredUsername: true,
                                        user: user
                                    });
                                }
                            })






                    }
                    else {





                        let user = ModelUser.findOne({ where: { username: req.query.id } })






                        let userx = ModelUser.findOne({ where: { username: req.query.id } })

                        // Retrieve ID from URL



                        try {
                            ModelUser.update({
                                username: req.body.username,
                                email: req.body.email,
                                phoneNumber: req.body.number,
                                address: req.body.address,
                                role: req.body.role,
                                accountStatus: req.body.status,
                            }, {
                                where: { username: req.query.id }
                            })

                            var userHasComment = ModelComment.findOne({ where: { "username": req.query.id } })

                            if (userHasComment) {

                                ModelComment.update({
                                    username: req.body.username,
                                }, {
                                    where: { username: req.query.id }
                                })
                            }

                        }

                        catch {
                            console.error(error);
                        }



                        if (req.body.number != res.locals.user.phoneNumber) {
                            ModelUser.update({

                                phoneNumberVerified: "0",
                            }, {
                                where: { username: req.query.id }
                            })
                                .catch(err => console.log(err)
                                );
                        }


                        ModelUser.update({

                            emailVerified: "0",
                        }, {
                            where: { username: req.query.id }
                        })
                            .catch(err => console.log(err)
                            );

                        if (req.body.number != res.locals.user.phoneNumber) {
                            ModelUser.update({

                                phoneNumberVerified: "0",
                            }, {
                                where: { username: req.query.id }
                            })
                                .catch(err => console.log(err)
                                );
                        }

                        if (user.username != res.locals.user.username) { return res.redirect('/staff/accounts/list') }
                        else {
                            req.logout();
                            return res.redirect('/auth/login')
                        }



                    }
                }
                )

        }


        else {

            console.log("EGGEGGDOLPHIN")







            let user = ModelUser.findOne({ where: { username: req.query.id } })




            // ModelUser.findOne({ where: { email: req.body.email } })
            //     .then(user => {
            //         if (user) {
            //             console.log("email already registered.")
            //             return res.render('staff/accounts/updateUsers.html', {
            //                 registeredEmail: true,
            //             });


            //         }

            ModelUser.findOne({ where: { email: req.body.email } })
                .then(user => {
                    if (user) {
                        if (req.body.email != res.locals.user.email && req.body.username == res.locals.user.username) {





                            // benedick

                            ModelUser.findOne({ where: { username: req.query.id } })
                                .then(user => {
                                    if (user) {

                                        return res.render('staff/accounts/updateUsers.html', {
                                            registeredEmail: true,
                                            user: user
                                        });
                                    }
                                })






                        }
                    }

                    ModelUser.findOne({ where: { username: req.body.username } })
                        .then(user => {
                            if (user) {




                                ModelUser.findOne({ where: { username: req.query.id } })
                                    .then(user => {
                                        if (user) {

                                            return res.render('staff/accounts/updateUsers.html', {
                                                registeredUsername: true,
                                                user: user
                                            });
                                        }
                                    })




                            }


                            else {



                                let userx = ModelUser.findOne({ where: { username: req.query.id } })

                                // Retrieve ID from URL

                                ModelUser.update({

                                    emailVerified: "0",
                                }, {
                                    where: { username: req.query.id }
                                })
                                    .catch(err => console.log(err)
                                    );


                                if (req.body.number != res.locals.user.phoneNumber) {
                                    ModelUser.update({

                                        phoneNumberVerified: "0",
                                        number: req.body.number

                                    }, {
                                        where: { username: req.query.id }
                                    })
                                        .catch(err => console.log(err)
                                        );
                                }




                                try {
                                    ModelUser.update({
                                        username: req.body.username,
                                        email: req.body.email,
                                        phoneNumber: req.body.number,
                                        address: req.body.address,
                                        role: req.body.role,
                                        accountStatus: req.body.status,
                                    }, {
                                        where: { username: req.query.id }
                                    })

                                    var userHasComment = ModelComment.findOne({ where: { "username": req.query.id } })

                                    if (userHasComment) {

                                        ModelComment.update({
                                            username: req.body.username,
                                        }, {
                                            where: { username: req.query.id }
                                        })
                                    }

                                }

                                catch {
                                    console.error(error);
                                }





                                ModelUser.findOne({ where: { username: req.query.id } })
                                .then(user => {
                                    if (user) {

                                        if (user.username != res.locals.user.username) { return res.redirect('/staff/accounts/list') }
                                        else {
                                            req.logout();
                                            return res.redirect('/auth/login')
                                        }

                                    }
                                })














                                // let user = ModelUser.findOne({ where: { username: req.query.id } })

                                // // Retrieve ID from URL

                                // if (fs.existsSync(user.urlPic)) {
                                // 	fs.unlinkSync(user.urlPic)
                                // }
                                // try {
                                // 	ModelUser.update({
                                // 		username: req.body.username,
                                // 		email: req.body.email,
                                // 		phoneNumber: req.body.number,
                                // 		address: req.body.address,
                                // 		urlPic: paths[0]
                                // 	}, {
                                // 		// shabboozey
                                // 		where: { username: req.query.id }
                                // 	})
                                // 	var userHasComment = ModelComment.findOne({ where: { "username": req.query.id } })

                                // 	if (userHasComment) {

                                // 		ModelComment.update({
                                // 			username: req.body.username,
                                // 			urlPic: paths[0]
                                // 		}, {
                                // 			where: { username: req.query.id }
                                // 		})
                                // 	}

                                // }
                                // catch {
                                // 	console.error(error);
                                // }


                                // if (req.body.email != res.locals.user.email) {


                                // 	if (req.body.email != undefined) {
                                // 		ModelUser.update({

                                // 			emailVerified: "0",
                                // 		}, {
                                // 			where: { username: req.query.id }
                                // 		})
                                // 			.catch(err => console.log(err)
                                // 			);
                                // 		req.logout();
                                // 	}
                                // }


                                // return res.redirect('/profile?success=true')







                            }
                        }
                        );
                });



        }













    }
}



async function resetUserPw(req, res) {
    // HERE

    let user = await ModelUser.findOne({ where: { uuid: req.params.uuid } })
    const uuid = user.uuid

    const secret = 'secret';
    let token = JWT.sign({
        uuid: user.uuid
    },
        secret, {
        expiresIn: "1hr"
    });

    try {

        // create reusable transporter object using the default SMTP transport
        let transporter = nodemailer.createTransport({
            host: "smtp.gmail.com", // hostname
            secureConnection: false, // TLS requires secureConnection to be false
            port: 587,
            secure: false, // true for 465, false for other ports
            auth: {
                user: "contact.breadington.official@gmail.com", // generated ethereal user
                pass: "Bre@dington558824", // generated ethereal password
            },
            tls: {
                ciphers: 'SSLv3'
            }
        });

        // send mail with defined transport object
        transporter.sendMail({
            from: '"Breadington 👻" contact.breadington.official@gmail.com', // sender address
            to: user.email, // list of receivers
            subject: "Password Reset", // Subject line
            text: "You requested a link to change your password.",// plain text body
            html: "<h1>Forgot your password?</h1><br>You requested a link to change your password. (If you didn't request this, you can ignore this email.)<br>reset your password by clicking on the link below <br>" + "http://localhost:3000/auth/password-reset/" + uuid + "/" + token,
        });

        console.log("Password reset link sent");
        return res.redirect('/staff/accounts/list?linkSent=true')
    }
    catch (error) {

        console.error(`Error sending verification`);
        console.error(error);
    }


    return res.render('/staff/accounts/list')



}

async function viewUser_page(req, res) {

    // Enable this to prevent guests from accessing the page.
    if (!res.locals.user || res.locals.user.role == "Guest") {
        return res.redirect('/error403')
    }



    ModelUser.findAll().then((user) => {
        return res.render('staff/accounts/retrieveUsers.html', {
            users_list: user,
            current_user: res.locals.user,
            sentPwReset: req.query.linkSent
        });
    }).catch(err => console.log(err)); // To catch no video ID
    // res.render('staff/retrieveUsers.html');
}


const Op = Sequelize.Op

/**
 * 
 * @param req {import('express').Request}
 * @param res {import('express').Response}
 * @returns 
 */

async function viewUser_data(req, res) {

    // const users = await ModelUser.findAll({raw: true});
    /**
     * @type {WhereOptions}
     */
    const condition = (req.query.search) ? {
        [Op.or]: {
            "username": { [Op.substring]: req.query.search },
            "email": { [Op.substring]: req.query.search },
        }
    } : undefined;

    const total = await ModelUser.count({
        where: condition
    });

    const users = await ModelUser.findAll({
        where: condition,
        // offset: parseInt(req.query.offset),
        // limit: parseInt(req.query.limit),
        order: (req.query.sort) ? [[req.query.sort, req.query.order.toUpperCase()]] : undefined,
        raw: true
    })


    return res.json({
        "rows": users,
        // "total": users.length
        "total": total
    }
    )


}


// //create walk in user -yh
// router.get("/createWalkInUser", async function (req, res) {
//     console.log("create walk in user page accessed");
//     return res.render('staff/createWalkInUser.html');
// });

// router.post("/createWalkInUser", async function (req, res) {
//     let { fullName, nric, gender, phoneNumber, temperature } = req.body;
//     WalkInUser.create({ fullName: req.body.fullName, nric: req.body.nricy, gender: req.body.gender, phoneNumber: req.body.phoneNumber, temperature: req.body.temperature })
//         .then(WalkInUser => {
//             console.log(WalkInUser.fullName + "success db")
//             res.redirect('/');
//         })
//         .catch(err => console.log(err + "what is this"));
// });