import bodyParser from 'body-parser';
import urlencoded from 'urlencode';
import alertMessage from 'flash-messenger';
import bcrypt from 'bcryptjs';
import Passport from 'passport';
import Hash from 'hash.js';
import { response, Router } from 'express';
import nodemailer from 'nodemailer';
import twilio from 'twilio';
import multer from 'multer';
import request from 'request';
var upload = multer({ dest: 'public/userPic' })
import requestIp from 'request-ip';
import JWT from 'jsonwebtoken';
import { ModelUser } from '../data/user.mjs';

const router = Router();
export default router;

router.get("/login", login_page);
router.post("/login", login_process);
router.get("/register", register_page);
router.post("/register", upload.single('avatar'), register_process);
router.get("/begin-password-reset", password_reset);
router.post("/begin-password-reset", password_reset_process);
router.get("/password-reset/:uuid/:token", confirm_password_reset)
router.post("/password-reset/:uuid/:token", confirm_password_process)
router.get("/logout", logout_process);



/**
 * 
 * @param req {import('express').Request}
 * @param res {import('express').Response}
 * @returns 
 */
async function login_page(req, res) {

	console.log("Login page accessed");

	return res.render('auth/login.html', {

		success: req.query.success,
		login_failed: req.query.invalid,
		pwResetSuccess: req.query.passwordUpdated
	}
	);
}



/**
 * 
 * @param req {import('express').Request}
 * @param res {import('express').Response}
 * @returns 
 */

async function login_process(req, res, next) {
	console.log("Incoming Request");
	console.log(req.body);

	return Passport.authenticate('local', {
		successRedirect: "/",
		failureRedirect: "/auth/login?invalid=true",
	})(req, res, next);

}

/**
 * 
 * @param req {import('express').Request}
 * @param res {import('express').Response}
 * @returns 
 */
async function register_page(req, res) {
	console.log("Register page accessed");
	return res.render('auth/register.html');
}


/**
 * 
 * @param req {import('express').Request}
 * @param res {import('express').Response}
 * @returns 
 */
async function register_process(req, res) {
	if (
		req.body['g-recaptcha-response'] === undefined ||
		req.body['g-recaptcha-response'] === '' ||
		req.body['g-recaptcha-response'] === null
	) {
		return res.json({ "success": false, "msg": "Please select captcha" })
	}

	// Secret Key
	const secretKey = "6LdTc1cbAAAAAAnlZmE6sdRCw_RV_Qgll8E5t88Y";

	// Verify URL

	const query = JSON.stringify({
		secret: secretKey,
		response: req.body['g-recaptcha-response'],
		remoteip: req.remoteAddress
	});
	// Make Request to VerifyURL

	var verificationUrl = "https://www.google.com/recaptcha/api/siteverify?secret=" + secretKey + "&response=" + req.body['g-recaptcha-response'] + "&remoteip=" + req.clientIp;
	// Hitting GET request to the URL, Google will respond with success or error scenario.
	request(verificationUrl, function (error, response, body) {
		body = JSON.parse(body);
		if (body.success !== undefined && !body.success) {
			console.log("Captcha verification failed fuck")
			return res.redirect('/auth/register')
		}
		console.log(body.success)
		let { username, email, password, password2, phoneNumber, address } = req.body;

		ModelUser.findOne({ where: { email: req.body.email } })
			.then(user => {
				if (user) {
					console.log("email already registered.")
					return res.render('auth/register.html', {
						registeredEmail: true,
					});
				}
				ModelUser.findOne({ where: { username: req.body.username } })
					.then(user => {
						if (user) {
							console.log("username already registered.")

							return res.render('auth/register.html', {
								registeredUsername: true,
							});
						}
						else {

							// JWT Token that expires in 30 minutes

							const secret = 'secret';
							let token = JWT.sign({
								email: req.body.email
							},
								secret, {
								expiresIn: "1hr"
							});


							console.log(token)

							let verification_hash = Hash.sha256().update(req.body.email).digest("hex")
							ModelUser.create({ username: req.body.username, email: req.body.email, password: Hash.sha256().update(req.body.password).digest("hex"), verification_hash: verification_hash, phoneNumber: req.body.number, address: req.body.address, phoneNumber_pin: Math.random().toString().substr(2, 4), urlPic: req.file.path })
								.then(user => {

									// Change auth token + uncomment this when doing demo

									// Sends number verification

									let accountSID = "AC1c886159e90de587c54a161fcbb7050d";
									
									let authToken = "7a69192e5a36f1b2eede358fa30f9e23";


									let client = new twilio(accountSID, authToken)

									client.messages 
										  .create({ 
											 body: 'Dear Customer, Your OTP for Breadington is ' + user.phoneNumber_pin + '. Use this Passcode to verify your phone number. Thank you.',  
											 messagingServiceSid: 'MG0d160ce6e5c9c06e5a148e1d983ab07b',      
											 to: '+65' + req.body.number 
										   }) 
										  .then(message => console.log(message.sid)) 
										  .done();


									// Sends email

									// create reusable transporter object using the default SMTP transport
									let transporter = nodemailer.createTransport({
										host: "smtp-mail.outlook.com", // hostname
										secureConnection: false, // TLS requires secureConnection to be false
										port: 587,
										secure: false, // true for 465, false for other ports
										auth: {
											user: "breadington.official@outlook.com", // generated ethereal user
											pass: "Bre@dington558824", // generated ethereal password
										},
										tls: {
											ciphers: 'SSLv3'
										}
									});

									// send mail with defined transport object
									transporter.sendMail({
										from: '"Breadington 👻" breadington.official@outlook.com', // sender address
										to: req.body.email, // list of receivers
										subject: "Hello ✔ Verification", // Subject line
										text: "Please click on this link: http://localhost:3000/confirmEmail/verify/" + token, // plain text body
										html: "<b>Thank you for your registration, " + req.body.username + "! <br> please verify your account here:</b> http://localhost:3000/confirmEmail/verify/" + token + "<br>" + '<img src="cid:unique@nodemailer.com"/>',
										attachments: [{
											filename: 'ThankYou.jpg',
											path: 'public/img/ThankYou.jpg',
											cid: 'unique@nodemailer.com' //same cid value as in the html img src
										}]
									});

									console.log("Message sent");
									return res.redirect('login/?success=true')
								})
								.catch(err => console.log(err));

						}
					});

			}
			)
			;
	});

}


async function password_reset(req, res) {
	return res.render('auth/bgnPwReset.html')
}



async function password_reset_process(req, res) {

	// hera



	const user = await ModelUser.findOne({ where: { email: req.body.email } });
	if (user === null) {
		console.log('Not found!');
		return res.render('auth/bgnPwCfm.html')

	} else {
		console.log(user.uuid);
	}


	const uuid = user.uuid


	const secret = 'secret';
	let token = JWT.sign({
		email: req.body.email
	},
		secret, {
		expiresIn: "1hr"
	});



	try {
		
		// create reusable transporter object using the default SMTP transport
		let transporter = nodemailer.createTransport({
			host: "smtp.gmail.com", // hostname
			secureConnection: false, // TLS requires secureConnection to be false
			port: 587,
			secure: false, // true for 465, false for other ports
			auth: {
				user: "contact.breadington.official@gmail.com", // generated ethereal user
				pass: "Bre@dington558824", // generated ethereal password
			},
			tls: {
				ciphers: 'SSLv3'
			}
		});

		// send mail with defined transport object
		transporter.sendMail({
			from: '"Breadington 👻" contact.breadington.official@gmail.com', // sender address
			to: req.body.email, // list of receivers
			subject: "Password Reset", // Subject line
			text: "Please click on this link: http://localhost:3000/confirmEmail/verify/" + token, // plain text body
			html: "<h1>Forgot your password?</h1><br>You requested a link to change your password. (If you didn't request this, you can ignore this email.)<br>reset your password by clicking on the link below <br>" + "http://localhost:3000/auth/password-reset/" + uuid + "/" + token,
		});

		console.log("Password reset link sent");
		return res.render('auth/bgnPwCfm.html')


	}
	catch (error) {

		console.error(`Error sending verification`);
		console.error(error);
		return res.render('auth/bgnPwCfm.html')


	}


	return res.render('auth/bgnPwCfm.html')
}






async function confirm_password_reset(req, res) {


	const uuid = req.params.uuid
	const token = req.params.token
	try {
		const payload = JWT.verify(token, 'secret');
		console.log("JWT Verified.")
		return res.render("auth/endPwReset.html");
	}
	catch (error) {

		console.error(`The token is invalid`);
		console.error(error);
		return res.redirect("/verification-failed")
	}

}



async function confirm_password_process(req, res) {

	console.log("Here are the inputs: (debugging)" + req.body.password)

	ModelUser.update({
		password: Hash.sha256().update(req.body.password).digest("hex")	}, {
		where: {
			uuid: req.params.uuid
		}
	})
	.catch(err => console.log(err));

	console.log("Password successfuly updated!")
	return res.redirect("/auth/login?passwordUpdated=true");
}


/**
 * Logs out the current user
 * @param req {import('express').Request}
 * @param res {import('express').Response}
 * @returns 
 */
async function logout_process(req, res) {
	req.logout();
	return res.redirect("login");
}
