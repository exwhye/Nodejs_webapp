import { Router } from 'express';
import { ModelProduct } from '../data/createProduct.mjs';
import { ModelCart } from '../data/cart.mjs';
import { ModelUser } from '../data/user.mjs';
import sequelize from 'sequelize';
const router = Router();
export default router;

import RouterCheckout from '../routes/checkout.mjs'
router.use("/checkout", RouterCheckout)

router.get("/", Cart)
router.post("/add", addCart)
router.post("/qtyUpdate", qtyUpdate)
router.post("/delCart", deleteCart)


//not done
async function Cart(req, res) {
    if (!res.locals.user) {
        return res.redirect("/auth/login");

    }

    if (res.locals.user.emailVerified == 0 || res.locals.user.phoneNumberVerified == 0) {
        return res.redirect("/");
    }    
    try {
        const user = req.user.uuid
        const items = await ModelUser.findOne({
            where: {
                uuid: user,
            },
            include: [{ model: ModelProduct, as: "Products" }]
        });

        const getTotal = await ModelCart.findAll({
            attributes: ['uuid_user', [sequelize.fn('sum', sequelize.col('subTotal')), 'total']],
            raw: true,
        });

        const getCount = await ModelCart.findAll({
            attributes: ['uuid_user', [sequelize.fn('count', sequelize.col('uuid_user')), 'count']],
            raw: true,
        });
        const x = items.Products
        console.log(x)
        return res.render('customer/cart.html', {
            cart: x,
            total: getTotal,
            count: getCount
        })
    }
    catch (err) {
        console.log(err);
        res.status(500).send("Something went wrong");
    }

}

async function addCart(req, res) {
    const cuid = req.user.uuid
    const puid = req.body.productId
    const qty = req.body.qty
    const getProductInfo = await ModelProduct.findOne({ where: { product_uuid: puid } })
    const getCartInfo = await ModelCart.findOne({ where: { product_uuid: puid } })
    try {
        if (getCartInfo === null) {
            const subTotal = getProductInfo.price * parseInt(qty)
            await ModelCart.create({
                product_uuid: puid,
                uuid_user: cuid,
                qty: qty,
                subTotal: subTotal
            })
            await ModelProduct.update({
                stockCount: getProductInfo.stockCount - parseInt(qty),
            }, {
                where: {
                    product_uuid: puid
                }
            })
            console.log("success, created and added to cart")

        } else {
            const updatedSubtotal = parseInt(getCartInfo.subTotal) + getProductInfo.price * parseInt(qty)

            await ModelProduct.update({
                stockCount: getProductInfo.stockCount - parseInt(qty),
            }, {
                where: {
                    product_uuid: puid
                }
            })
            console.log("update qty for ModelProduct")

            await ModelCart.update({
                qty: getCartInfo.qty + parseInt(qty),
                subTotal: updatedSubtotal,
            }, {
                where: {
                    product_uuid: puid
                }
            })
            console.log("update qty for ModelCart")
        }
        return res.json(getProductInfo.stockCount - parseInt(qty))
    }
    catch (error) {
        console.error(error);
        return res.status(500).end();
    };

}

async function qtyUpdate(req, res) {
    const cuid = req.user.uuid
    const puid = req.body.productId
    const qty = req.body.qty
    const getProductInfo = await ModelProduct.findOne({ where: { product_uuid: puid } })
    const getCartInfo = await ModelCart.findOne({ where: { product_uuid: puid } })
    const getCartInfoAll = await ModelCart.findAll()
    try {
        let updatedSubtotal = getProductInfo.price * parseInt(qty)
        let qtyChange = parseInt(qty) - parseInt(getCartInfo.qty)
        console.log(updatedSubtotal)
        
        await ModelProduct.update({
            stockCount: getProductInfo.stockCount - qtyChange,
        }, {
            where: {
                product_uuid: puid
            }
        })
        console.log("update change for ModelProduct") 

        await ModelCart.update({
            qty: getCartInfo.qty + qtyChange,
            subTotal: updatedSubtotal,
        }, {
            where: {
                product_uuid: puid
            }
        })
        console.log("update qty for ModelCart")
        const getTotal = await ModelCart.findAll({
            attributes: ['uuid_user', [sequelize.fn('sum', sequelize.col('subTotal')), 'total']],
            raw: true,
        });
        return res.json({cart:getCartInfoAll,total:getTotal})
    }
    catch (error) {
        console.error(error);
        return res.status(500).end();
    };

}

async function deleteCart(req, res) {
    const prdtID = req.body.delprdtid;
    const getProductInfo = await ModelProduct.findOne({ where: { product_uuid: prdtID } })
    const getCartInfo = await ModelCart.findOne({ where: { product_uuid: prdtID } })
    try {
        await ModelCart.destroy({
            where: { "product_uuid": prdtID }
        })
        await ModelProduct.update({
            stockCount: getProductInfo.stockCount + parseInt(getCartInfo.qty)
        }, {
            where: {
                product_uuid: prdtID
            }
        })

    } catch (error) {
        console.error(error);
        return res.status(500).end();
    };

    console.log("cart deleted")
    return res.json()

}

