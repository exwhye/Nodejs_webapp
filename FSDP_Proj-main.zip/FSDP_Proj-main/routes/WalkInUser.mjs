import { Router } from 'express';
import { ModelWalkIn } from '../data/createWalk.mjs';
import Sequelize from 'sequelize';
import fs from 'fs';
// import { UploadTo, DeleteFile, DeleteFilePath, UploadFile } from '../utils/multer.mjs';
import { flash_message } from '../helpers/flash-messenger.mjs';
const router = Router();
export default router;


//create walk in customer codes
router.get("/createWalkInUser", createWalkInUser)
router.post("/createWalkInUser", createWalkInUserPost)
router.get("/displayWalkInUser", displayWalkInUser)
router.get("/displayWalkInUser-data", displayWalkInUserData)
router.get("/updateWalkInUser", updateWalkInUser)
router.post("/updateWalkInUser", updateWalkInUserPost)
router.get("/deleteWalkInUser", deleteWalkInUser)


async function createWalkInUser(req, res) {
    console.log("create walk in user page accessed");
    return res.render('staff/walkInUser/createWalkInUser.html');
};

async function createWalkInUserPost(req, res) {
    try {
        console.log(req.body)
        const walkInUser = await ModelWalkIn.create({
            fullName: req.body.fullName,
            nric: req.body.nric,
            gender: req.body.gender,
            phoneNumber: req.body.phoneNumber,
            temperature: req.body.temperature,
        });
        console.log(walkInUser.fullName + "success db")
       
        
        
        return res.redirect("http://localhost:3000/staff/walkInUser/displayWalkInUser")
    }
    catch (error) {
        // console.error(`File is uploaded but something crashed`);
        console.error(error);
        return res.sendStatus(400).end();
    }
}


async function displayWalkInUser(req, res) {
    ModelWalkIn.findAll().then((customers) => {
        return res.render('staff/walkInUser/displayWalkInUser.html'), {
            walkInUserList: customers
        }
    }).catch(err => console.log(err))
}

const Op = Sequelize.Op


async function displayWalkInUserData(req, res) {
    //const customers = await ModelWalkIn.findAll({raw: true});
    /**
         * @type {WhereOptions}
         */
    const condition = (req.query.search) ? {
        [Op.or]: {
            "fullName": { [Op.substring]: req.query.search }           
        }
    } : undefined;

    const total = await ModelWalkIn.count({
        where: condition
    });

    const customerss = await ModelWalkIn.findAll({
        where: condition,
        // offset: parseInt(req.query.offset),
        // limit: parseInt(req.query.limit),
        order: (req.query.sort) ? [[req.query.sort, req.query.order.toUpperCase()]] : undefined,
        raw: true
    })
    return res.json({
        "total": total,
        "rows": customerss
    });

};



async function updateWalkInUser(req, res) {
    return res.render('staff/walkInUser/updateWalkInUser.html', {
        walkInUser_uuid: req.query.id,
        updateDB : true,

    });
}

async function updateWalkInUserPost(req, res) {
    // Retrieve ID from URL
    try {
        console.log(req.body)
        ModelWalkIn.update({
            fullName: req.body.fullName,
            nric: req.body.nric,
            gender: req.body.gender,
            phoneNumber: req.body.phoneNumber,
            temperature: req.body.temperature
        }, {
            where: {
                walkInUser_uuid: req.query.id
            }
        })
        // flash_message(res,warn,)
        return res.redirect("/staff/walkInUser/displayWalkInUser")
    }
    catch (error) {
        console.error(error);
        return res.status(500).end();
    };
}


async function deleteWalkInUser(req, res) {
    ModelWalkIn.destroy({
        where: { "walkInUser_uuid": req.query.id }
    })
        .catch(err => console.log(err));
    console.log("Customer deleted")
    return res.redirect('/staff/walkInUser/displayWalkInUser')
}