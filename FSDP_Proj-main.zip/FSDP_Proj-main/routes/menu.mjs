import { Router } from 'express';
import { ModelProduct } from '../data/createProduct.mjs';
const router = Router();
export default router;

router.get("/menu", menu)
router.get("/menu/:uuid", details)

async function menu(req, res) {

    if (!res.locals.user) {
        return res.redirect("/auth/login");

    }


    if (res.locals.user.emailVerified == 0 || res.locals.user.phoneNumberVerified == 'False' || res.locals.user.phoneNumberVerified == '0') {
        return res.redirect("/");
    }    

    const product = await ModelProduct.findAll()
    return res.render('customer/menu.html', {
        product_list: product
    })
}

async function details(req, res) {
    if (!res.locals.user) {
        return res.redirect("/auth/login");
    }
    if (res.locals.user.emailVerified == 0 || res.locals.user.phoneNumberVerified == 0) {
        return res.redirect("/");
    }  
    const id = req.params.uuid;
    const details = await ModelProduct.findByPk(id);
    if (details == null) {
        console.log("UUID Not found!")
    } else {
        return res.render('customer/details.html', {
            details: details
        })
    }

}