import ORM from 'sequelize'
const { Sequelize, DataTypes, Model } = ORM;


export class ModelWalkIn extends Model{
	/**
	 * Initializer of the model
	 * @see Model.init
	 * @access public
	 * @param {Sequelize} database The configured Sequelize handle
	**/
	static initialize(database) {
		ModelWalkIn.init({
			"walkInUser_uuid"  : { type: DataTypes.CHAR(36),    primaryKey: true, defaultValue: DataTypes.UUIDV4 },
			"fullName"         : { type: DataTypes.STRING(128), allowNull: false },
			"nric"             : { type: DataTypes.STRING(128), allowNull: false },
			"gender"           : { type: DataTypes.STRING(36),  allowNull: false },
			"phoneNumber"      : { type: DataTypes.STRING(39),    allowNull: false },
			"temperature"      : { type: DataTypes.FLOAT(3,1),  allowNull: false },
			role: {type: Sequelize.ENUM, values: ['walkIn'],defaultValue: "walkIn", allowNull: false},
			dateCreated		   : { type: Sequelize.DATEONLY, defaultValue: Sequelize.NOW},
    		dateUpdated		   : { type: Sequelize.DATEONLY, defaultValue: Sequelize.NOW},
			// timeCreated		   : { type: Sequelize.TIMEONLY, defaultValue: Sequelize.NOW},
    		// timeUpdated		   : { type: Sequelize.TIMEONLY, defaultValue: Sequelize.NOW},
			// "dateUpdated"      : { type: DataTypes.DATE(),      allowNull: false, defaultValue: Sequelize.literal('CURRENT_TIMESTAMP') },

		}, {
			"sequelize": database,
			"modelName": "WalkInUser",
			"hooks"    : {
				"afterUpdate": ModelWalkIn._auto_update_timestamp
			}
		});
	}

	/**
	 * Emulates "TRIGGER" of "AFTER UPDATE" in most SQL databases.
	 * This function simply assist to update the 'dateUpdated' timestamp.
	 * @private
	 * @param {ModelWalkIn}      instance The entity model to be updated
	 * @param {UpdateOptions}    options  Additional options of update propagated from the initial call
	**/
	static _auto_update_timestamp(instance, options) {
		// @ts-ignore
		instance.dateUpdated = Sequelize.literal('CURRENT_TIMESTAMP');
	}
}