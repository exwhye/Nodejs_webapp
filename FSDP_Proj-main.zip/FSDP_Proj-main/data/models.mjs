import ORM from 'sequelize'
const { Sequelize, DataTypes, Model } = ORM;
import { ModelProduct }  from '../data/createProduct.mjs';
import { ModelUser }     from '../data/user.mjs';
import { ModelCode }     from '../data/code.mjs'
import { ModelReward }   from '../data/rewards.mjs';
import { ModelCart }     from '../data/cart.mjs';
import { ModelWalkIn }   from '../data/createWalk.mjs';
import { ModelDiscount } from './discounts.mjs';
import { ModelComment }  from './comment.mjs';
import { ModelOrder }    from './orders.mjs'
/* Creates a user(s) table in MySQL Database.
Note that Sequelize automatically pleuralizes the entity name as the table name
*/
export function initialize_models(database) {
	try {
		console.log("Intitializing ORM models");
		//	Initialzie models
		ModelDiscount.initialize(database);
		ModelProduct.initialize(database);
		ModelUser.initialize(database);
		ModelCode.initialize(database);
		ModelReward.initialize(database);
		ModelCart.initialize(database);
		ModelComment.initialize(database);
		ModelWalkIn.initialize(database);
		ModelOrder.initialize(database);


		//	Create relations between models or tables
		//	Setup foreign keys, indexes etc
		ModelUser   .belongsToMany(ModelProduct, { through: ModelCart, foreignKey: "uuid_user" });
		ModelProduct.belongsToMany(ModelUser,    { through: ModelCart, foreignKey: "product_uuid" });

		// ModelUser   .belongsToMany(ModelCart, { through: ModelOrder, foreignKey: "uuid_user" });
		// ModelCart.belongsToMany(ModelUser,    { through: ModelOrder, foreignKey: "uuid_user" });

		ModelUser.belongsToMany(ModelCode, {through: ModelDiscount, foreignKey:"account"})
		ModelCode.belongsToMany(ModelUser,{through: ModelDiscount, foreignKey:"code"})

		ModelComment.initialize(database);
		console.log("Building ORM model relations and indices");
	}
	catch (error) {
		console.error ("Failed to configure ORM models");
		console.error (error);
	}
}



