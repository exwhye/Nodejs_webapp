
import ORM from 'sequelize'
const { Sequelize, DataTypes, Model } = ORM;


export class ModelComment extends Model {
	/**
	 * Initializer of the model
	 * @see Model.init
	 * @access public
	 * @param {Sequelize} database The configured Sequelize handle
	**/
	static initialize(database) {

		ModelComment.init({
			username: { type: Sequelize.STRING, allowNull: false },
			urlPic: {type: Sequelize.STRING, allowNull: false},
			emailVerified: { type: Sequelize.STRING, defaultValue: "False", allowNull: false },
			comment: { type: Sequelize.TEXT, allowNull: true },
			role: { type: Sequelize.ENUM, values: ['Guest', 'Staff'], defaultValue: "Guest", allowNull: false },
			dateCreated: {
				 type: Sequelize.DATE, defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
			},

		}, {
			"sequelize": database,
			"modelName": "comment",
			"hooks": {
				"afterUpdate": ModelComment._auto_update_timestamp
			}
		});
	}

	/**
	 * Emulates "TRIGGER" of "AFTER UPDATE" in most SQL databases.
	 * This function simply assist to update the 'dateUpdated' timestamp.
	 * @private
	 * @param {ModelComment}     instance The entity model to be updated
	 * @param {UpdateOptions} options  Additional options of update propagated from the initial call
	**/
	static _auto_update_timestamp(instance, options) {
		// @ts-ignore
		instance.dateUpdated = Sequelize.literal('CURRENT_TIMESTAMP');
	}


	formateddate(){
		return this.dateCreated.getDate().toString() +"/"+ this.dateCreated.getMonth().toString() +"/"+ this.dateCreated.getFullYear().toString() +"           "+ this.dateCreated.toLocaleTimeString()
	}


}
