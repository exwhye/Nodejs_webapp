import ORM from 'sequelize'
import { ModelUser }    from '../data/user.mjs';
import { ModelCode }    from '../data/code.mjs';
const { Sequelize, DataTypes, Model } = ORM;


export class ModelDiscount extends Model{
	/**
	 * Initializer of the model
	 * @see Model.init
	 * @access public
	 * @param {Sequelize} database The configured Sequelize handle
	**/
	static initialize(database) {
		ModelDiscount.init({
            "code"       : {type: DataTypes.CHAR(36), primaryKey:true, allowNull: false},
            "account"    : {type: DataTypes.CHAR(36), primaryKey:true, allowNull: false}
		}, {
			"sequelize": database,
			"modelName": "discount",
			"hooks"    : {
				"afterUpdate": ModelDiscount._auto_update_timestamp
			}
		});
	}

	/**
	 * Emulates "TRIGGER" of "AFTER UPDATE" in most SQL databases.
	 * This function simply assist to update the 'dateUpdated' timestamp.
	 * @private
	 * @param {ModelDiscount}     instance The entity model to be updated
	 * @param {UpdateOptions} options  Additional options of update propagated from the initial call
	**/
	static _auto_update_timestamp(instance, options) {
		// @ts-ignore
		instance.dateUpdated = Sequelize.literal('CURRENT_TIMESTAMP');
	}
    get uuid() {return this.getDataValue("uuid")}
    get code() {return this.getDataValue("code")}
    get account() {return this.getDataValue("account")}
}
